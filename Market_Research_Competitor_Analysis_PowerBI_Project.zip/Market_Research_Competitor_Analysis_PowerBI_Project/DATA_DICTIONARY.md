# Data Dictionary — Market Research and Competitor Analysis
All records are synthetic sample data created for learning and portfolio demonstration. They are not verified real-world market observations.

| Column | Meaning | Suggested Power BI type | Validation |
|---|---|---|---|
| Date | Date of the product-market observation | Date | Valid date; 2024–2025 |
| Company Name | Simulated company label | Text | Trim whitespace; standardize case/spelling |
| Product Name | Simulated product name | Text | Nonblank |
| Product Category | Product category | Text | Standardize to five known categories |
| Region | Sales region | Text | North, South, East, West, Central |
| Product Price | Simulated unit price in INR | Fixed decimal / Currency | Must be > 0 |
| Units Sold | Units sold for the observation | Whole number | Must be >= 1 |
| Revenue | Sales revenue in INR | Fixed decimal / Currency | Should equal Product Price × Units Sold |
| Customer Rating | Simulated customer rating | Decimal number | 1.0–5.0; missing values can be excluded from averages |
| Marketing Spend | Simulated marketing expense in INR | Fixed decimal / Currency | Must be >= 0 |

Dataset size: 1,800 rows, 6 companies, 25 products, 5 categories, 5 regions, dates across 2024–2025.
