# DAX Measures
Create a table named `Measures` (Home > Enter data; create one dummy column and hide it), or create measures under `MarketData`.
Names and columns below match the Excel `MarketData` sheet.

```DAX
Total Revenue =
SUM ( MarketData[Revenue] )

Total Units Sold =
SUM ( MarketData[Units Sold] )

Total Marketing Spend =
SUM ( MarketData[Marketing Spend] )

Average Product Price =
AVERAGE ( MarketData[Product Price] )

Average Customer Rating =
AVERAGE ( MarketData[Customer Rating] )

Total Companies =
DISTINCTCOUNT ( MarketData[Company Name] )

Total Products =
DISTINCTCOUNT ( MarketData[Product Name] )

Revenue by Region =
[Total Revenue]

Previous Month Revenue =
CALCULATE (
    [Total Revenue],
    DATEADD ( 'Calendar'[Date], -1, MONTH )
)

MoM Revenue Growth % =
VAR PreviousRevenue = [Previous Month Revenue]
RETURN
    IF (
        ISBLANK ( PreviousRevenue ) || PreviousRevenue = 0,
        BLANK (),
        DIVIDE ( [Total Revenue] - PreviousRevenue, PreviousRevenue )
    )

Revenue Contribution % =
DIVIDE (
    [Total Revenue],
    CALCULATE ( [Total Revenue], REMOVEFILTERS ( MarketData ) )
)

Top-Performing Company =
VAR CompanyRevenue =
    ADDCOLUMNS (
        ALLSELECTED ( MarketData[Company Name] ),
        "__Revenue", [Total Revenue]
    )
VAR TopCompany =
    TOPN ( 1, CompanyRevenue, [__Revenue], DESC, MarketData[Company Name], ASC )
RETURN
    CONCATENATEX ( TopCompany, MarketData[Company Name], ", " )

Sales Performance Classification =
VAR RevenueValue = [Total Revenue]
VAR RevenueMedian =
    MEDIANX (
        ALLSELECTED ( MarketData[Company Name] ),
        CALCULATE ( [Total Revenue] )
    )
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( RevenueValue ), "No data",
        RevenueValue >= RevenueMedian, "Above / equal to peer median",
        "Below peer median"
    )
```

## Important notes
- Set `MoM Revenue Growth %` and `Revenue Contribution %` to Percentage format.
- Format revenue, marketing spend, and product price as INR currency.
- `Revenue by Region` intentionally returns the current-context revenue; place Region on the visual axis.
- The contribution measure above compares the current selection with the total after removing filters from the fact table. In a star schema, prefer removing dimension filters explicitly if you want a different denominator, e.g. `REMOVEFILTERS('Company')` or `REMOVEFILTERS('Region')`.
- `Top-Performing Company` returns a label for the current filter context. For a ranking visual, use `[Total Revenue]` sorted descending instead.
