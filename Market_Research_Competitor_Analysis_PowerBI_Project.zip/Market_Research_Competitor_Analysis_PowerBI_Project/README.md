# Market Research and Competitor Analysis Using Microsoft Power BI

## Contents
- `market_research_competitor_analysis.xlsx` — clean sample data, data dictionary, and messy practice data.
- `market_research_competitor_analysis.csv` — clean sample data for CSV import.
- `DATA_DICTIONARY.md` — column meanings and validation rules.
- `POWER_QUERY_GUIDE.md` — Power Query cleaning walkthrough.
- `DATA_MODEL_AND_REPORT_GUIDE.md` — calendar table, relationships, report page design, and analysis questions.
- `DAX_MEASURES.md` — measures aligned to the `MarketData` table/columns.

## Dataset facts
- Rows: 1,800
- Companies: 6
- Products: 25
- Categories: 5
- Regions: 5
- Dates: 2024-01-01 to 2025-12-31

## Important
This is simulated data, generated for learning and portfolio use. Company names, sales, prices, ratings, and marketing expenses are fictional sample values, not verified real-world market data. Do not present sample findings as actual market research.

## Quick start
1. Open Power BI Desktop.
2. Home > Get data > Excel workbook > choose the `.xlsx` file.
3. Select `MarketData` > Transform Data; follow the Power Query guide.
4. Close & Apply.
5. Create the Calendar table and relationship as described in `DATA_MODEL_AND_REPORT_GUIDE.md`.
6. Create the measures in `DAX_MEASURES.md`.
7. Build the three report pages and answer the business questions using visuals.
8. Publish screenshots and a concise README to your portfolio. A `.pbix` report itself must be built and saved in Power BI Desktop; this package provides the data and implementation guide rather than a prebuilt PBIX.
