# Data Model and Report Build Guide

## Simple star-schema model
For a beginner-friendly version, keep `MarketData` as the fact table and create a separate `Calendar` date dimension. The fact table contains observations and numeric values; Calendar contains one row per date and attributes used for time filtering.

Create this calculated table from Modeling > New table:
```DAX
Calendar =
ADDCOLUMNS (
    CALENDAR ( MIN ( MarketData[Date] ), MAX ( MarketData[Date] ) ),
    "Year", YEAR ( [Date] ),
    "Month Number", MONTH ( [Date] ),
    "Month", FORMAT ( [Date], "MMM" ),
    "Year-Month", FORMAT ( [Date], "YYYY-MM" ),
    "Quarter", "Q" & FORMAT ( [Date], "Q" )
)
```
Then:
1. Select Calendar[Month] > Column tools > Sort by column > Month Number.
2. Select Calendar[Date] > Table tools > Mark as date table > choose Date.
3. Model view: relate `Calendar[Date]` (one side) to `MarketData[Date]` (many side).
4. Set Cross-filter direction to Single, from Calendar to MarketData; relationship active.
5. Use Calendar fields for date axes/slicers, not the fact table's Date column.

For a more advanced star schema, create Company, Product, Region and Category dimensions using Reference/Duplicate queries or DAX DISTINCT tables. Link each dimension's unique key/name (1) to MarketData (*), with single-direction filtering. Avoid connecting dimension tables to each other unless a valid business model requires it. Do not create many-to-many relationships just to remove an error.

## Report page design
Page 1 — Executive Overview:
- KPI cards: Total Revenue, Total Units Sold, Total Marketing Spend, Average Rating
- Line chart: Calendar[Year-Month] vs Total Revenue
- Bar chart: Company Name vs Total Revenue (descending)
- Donut or bar: Product Category vs Total Revenue
- Slicers: Calendar[Year], Region, Company Name

Page 2 — Competitor Analysis:
- Clustered bar: Company Name vs Total Revenue
- Matrix: Company Name × Product Category with Total Revenue
- Scatter chart: X = Total Marketing Spend, Y = Total Revenue, Details = Company Name (use aggregated measures; interpret as association, not causation)
- Table: Company Name, Average Product Price, Average Customer Rating, Total Revenue

Page 3 — Product & Regional Insights:
- Bar chart: Product Name vs Total Revenue / Units Sold
- Map is optional; use bar chart if location geography is not meaningful
- Matrix: Region × Product Category with Total Revenue
- Scatter chart: Average Product Price vs Average Customer Rating by Product Name
- Table for products with low sales / ratings

## Business questions to answer with visuals
1. Highest-revenue company: bar chart Company Name by Total Revenue, sort descending.
2. Best-performing category: Product Category by Total Revenue; optionally compare units sold.
3. Leading region: Region by Total Revenue and Revenue Contribution %.
4. Highest-rated products: Product Name with Average Customer Rating; filter for adequate sample size if using real data.
5. Monthly trend: line chart using Calendar[Year-Month] and Total Revenue.
6. Highest average prices by company: Company Name and Average Product Price.
7. Marketing vs revenue: scatter chart; check trend and outliers, do not infer causation from correlation.
8. Low-sales / low-rating products: table or scatter plot using Total Units Sold and Average Customer Rating; define thresholds transparently (e.g. bottom quartile sales or rating below 3.5) rather than arbitrary hidden assumptions.

## Portfolio disclaimer
All findings must be calculated from this generated sample dataset. State clearly: “This project uses synthetic sample data for demonstration; results do not represent verified company performance or actual market research.”
