# Power Query Cleaning Guide (Power BI Desktop)
Use the clean `MarketData` sheet for the main report. The workbook also includes `MessyPracticeData`, which intentionally contains a few issues to practice fixing.

## Import
1. Open Power BI Desktop.
2. Home > Get data > Excel workbook.
3. Select `market_research_competitor_analysis.xlsx`.
4. In Navigator, select `MarketData` (or `MessyPracticeData` for practice).
5. Select **Transform Data** to open Power Query Editor.

## Recommended cleaning steps
1. Rename the query to `MarketData` in the Query Settings > Name box.
2. Home > Remove Rows > Remove Duplicates. Select all columns first if a full-row duplicate is what you intend to remove. If records have a unique business key, remove duplicates using that key instead. This generated sample has no intentionally duplicated full rows.
3. For text fields (`Company Name`, `Product Name`, `Product Category`, `Region`): select columns > Transform > Format > Trim, then Clean. Use Replace Values or Transform > Format to standardize category/company spelling. In `MessyPracticeData`, uppercase and whitespace variants are intentional.
4. For missing ratings: select `Customer Rating`; use the column filter to inspect `(null)`. Keep nulls if rating is unknown; do not replace unknown ratings with 0 because 0 is not a valid rating. Remove rows only if the business rule says the record itself is unusable.
5. Validate numeric values: filter `Product Price` for values <= 0; filter `Units Sold` for values <= 0; filter `Customer Rating` outside 1–5; filter `Marketing Spend` < 0. Investigate before removing/correcting.
6. Set types with the icon left of each header or Transform > Data Type: Date, Text, Decimal Number / Fixed Decimal Number, Whole Number as appropriate.
7. Revenue check: Add Column > Custom Column. Name it `Expected Revenue`; formula:
   ` [Product Price] * [Units Sold] `
   Add another custom column `Revenue Difference`:
   ` [Revenue] - [Expected Revenue] `
   Filter absolute differences greater than a small tolerance (e.g. 0.01). Investigate and correct only if the source/business rule confirms revenue should be price × units.
8. Outliers: use View > Column profile / Column distribution / Column quality (turn on under View). Sort high-to-low and inspect extremes; use domain rules rather than deleting a value just because it is large.
9. Remove temporary validation columns after review if not needed. Keep meaningful cleaning steps visible in Applied Steps; rename steps with clear names where possible.
10. Home > Close & Apply.

## Documenting cleaning
Create a `Data Quality Log` page or a README table with: issue, column, rule, number of rows affected, action, reason. Do not claim a row was changed unless you actually performed the step. For the clean sample, validate types and revenue; for MessyPracticeData, you should discover intentionally introduced issues.
